<?php /* Template Name: ROI Page */ ?>
<?php
//get_header();
?>
<html lang="en" xml:lang="en" xmlns="http://www.w3.org/1999/xhtml">

<head>

	<meta charset="UTF-8">
	<meta http-equiv="Content-Language" content="en">

	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300..800;1,300..800&family=Raleway:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">

	<title>NeuraSignal - ROI</title>

</head>

<body>
	<style>
		body {
			background-color: #020618;
			color: #FFF;
			font-optical-sizing: auto;
			padding: 0;
			margin: 0;
		}

		.investment-page-margin {
			margin-left: 22em;
			margin-right: 22em;
		}

		@media (max-width: 1400px) {
			.investment-page-margin {
				margin-left: 11em;
				margin-right: 11em;
			}
		}

		@media (max-width: 1000px) {
			.investment-page-margin {
				margin-left: 5em;
				margin-right: 5em;
			}
		}

		@media (max-width: 700px) {
			.investment-page-margin {
				margin-left: 10px;
				margin-right: 10px;
			}
		}


		.investment-header {
			background-color: #080d1c;
			border-bottom: 2px solid #4C5F7E;
			text-align: center;
			padding-top: 10px;
			padding-bottom: 10px;
		}

		.form-background {
			background-color: #020618;
		}

		.investment-text-header,
		.investment-text-header-2line {
			font-family: "Raleway", sans-serif;
			font-size: 20px;
			font-weight: 800;
			text-align: center;
			margin-bottom: 10px;
			padding-top: 40px;
		}

		.investment-text-header-2line {
			margin-bottom: 0;
		}

		.investment-text-subheader {
			font-family: "Raleway", sans-serif;
			font-size: 14px;
			font-weight: 500;
			text-align: center;
			margin-bottom: 10px;
		}

		.investment-text-15px-label {
			font-family: "Open Sans", sans-serif;
			font-size: 15px;
			font-weight: 700;
		}

		.investment-text-14px-label {
			font-family: "Open Sans", sans-serif;
			font-size: 14px;
			font-weight: 600;
		}

		.investment-text-disclaimer {
			font-family: "Open Sans", sans-serif;
			font-size: 10px;
			font-weight: 300;
			text-align: center;
		}

		.investment-section-border {
			border: 2px solid #334666;
			background-color: #172236;
			border-radius: 20px;
			padding: 20px;
		}

		.investment-seperator {
			border-top: 1px dashed #334666;
			border-bottom: 1px dashed #334666;
			border-left: 0;
			border-right: 0;
			margin-top: 20px;
			margin-bottom: 20px;
		}

		.investment-list-indent {
			padding-left: 3em;
		}

		.investment-input-field,
		.investment-input-field-fullwidth,
		.investment-input-field-monthly-profit-fullwidth {
			border: 2px solid transparent;
			border-radius: 5px;
			text-align: center;
			background-color: #4C6C9A;
			color: #FFF;

			font-family: "Open Sans", sans-serif;
			font-size: 16px;
			font-weight: 600;

			padding: 12px;

			width: 100%;
		}

		.investment-input-field-fullwidth {
			width: 100%;
		}

		.investment-input-field-monthly-profit-fullwidth {
			font-weight: 800;
			width: 100%;
		}

		.investment-element-padding {
			padding-top: 20px;
		}

		.investment-label-padding {
			display: block;
			margin-bottom: 6px;
		}

		.fieldset-clear {
			border: none;
			padding-block: 0;
			padding-inline: 0;
			margin-inline: 0;
		}

		.submitButton {
			background-color: #35498F;
			color: white;
			/* background-color: #54BBE4; 
			color: black; */
			padding-top: 10px;
			padding-bottom: 10px;
			font-family: "Open Sans", sans-serif;
			font-size: 15px;
			font-weight: 600;
			border-radius: 12px;
			border: none;
			max-width: 300px;
			width: 100%;
		}

		input[type="checkbox"],
		input[type="radio"] {
			accent-color: #05c0e2;
			color: white;
			outline: 2px solid transparent;
		}

		input[type="checkbox"]:checked+label,
		input[type="radio"]:checked+label {
			accent-color: #05c0e2;
			color: #05c0e2;
		}

		.investment-output-form {
			display: none;
		}

		.addon-options-group {
			opacity: 50%;
		}

		/* Start: Form Group Percentage */
		.form-group-full-percentage {
			display: flex;
			align-items: center;
		}

		.form-group-full-percentage label {
			margin-left: 6px;
		}

		.form-group-full-percentage input {
			width: 100%;
		}

		/* End: Form Group Percentage */

		/* Start: Form Group Dollars */
		.form-group-full-dollars {
			display: flex;
			align-items: center;
		}

		.form-group-full-dollars label {
			margin-right: 6px;
		}

		.form-group-full-dollars input {
			width: 100%;
		}

		/* End: Form Group Dollars */
	</style>

	<style>
		.investment-container-2item {
			display: flex;
			flex-direction: row;
		}

		.investment-item-2row-item1 {
			flex-grow: 6;
			margin-right: 10px;
		}

		.investment-item-2row-item2 {
			flex-grow: 6;
			margin-left: 10px;
		}

		.investment-container-3item {
			display: flex;
			flex-direction: row;
		}

		.investment-item-3row-item1 {
			flex-grow: 4;
			margin-right: 10px;
		}

		.investment-item-3row-item2 {
			flex-grow: 4;
			margin-left: 5px;
			margin-right: 5px;
		}

		.investment-item-3row-item3 {
			flex-grow: 4;
			margin-left: 10px;
		}

		@media (max-width: 835px) {
			.mobile-padding {
				margin-bottom: 10px;
			}

			.investment-container-2item {
				display: flex;
				flex-direction: column;
			}

			.investment-item-2row-item1 {
				flex-grow: 12;
				margin-right: 0;
				/* margin-bottom: 10px; */
			}

			.investment-item-2row-item2 {
				flex-grow: 12;
				margin-left: 0;
			}

			.investment-container-3item {
				display: flex;
				flex-direction: column;
			}

			.investment-item-3row-item1 {
				flex-grow: 12;
				margin-right: 0;
				margin-bottom: 10px;
			}

			.investment-item-3row-item2 {
				flex-grow: 12;
				margin-left: 0;
				margin-right: 0;
			}

			.investment-item-3row-item3 {
				flex-grow: 12;
				margin-left: 0;
				margin-top: 10px;
			}
		}
	</style>

	<script>
		// Calculate the average number of patients per month, rounded to the nearest whole number.
		function averagePatientsCalc() {
			const annualPatients = document.getElementById("investment-form-annual-patients").value;
			const averageMonthlyPatients = Math.round(annualPatients / 12);

			document.getElementById("investment-form-average-monthly-patients").value = averageMonthlyPatients;
		}

		// Calculate the Location Payer Mix percentages. Total should be 100% otherwise it is an error.
		function locationPayerMix() {
			//Private Insurance
			let userPrivateInsurance = document.getElementById("investment-form-private-insurance").value;
			if (userPrivateInsurance === "") {
				userPrivateInsurance = 0;
			}

			//Medicaid
			let userMedicaid = document.getElementById("investment-form-medicade").value;
			if (userMedicaid === "") {
				userMedicaid = 0;
			}

			//Medicare
			let userMedicare = document.getElementById("investment-form-medicare").value;
			if (userMedicare === "") {
				userMedicare = 0;
			}

			//Uninsured / No-Pay
			let userUninsured = document.getElementById("investment-form-uninsured").value;
			if (userUninsured === "") {
				userUninsured = 0;
			}

			const userMixTotal = parseInt(userPrivateInsurance) + parseInt(userMedicaid) + parseInt(userMedicare) + parseInt(userUninsured);

			document.getElementById("investment-form-payer-total").value = userMixTotal;

			if (userMixTotal !== 100) {
				checkLocationPayerMixTotal();
				document.getElementById("payer-error-message").style.display = "block";

				const userMixDifference = userMixTotal - 100;

				if (userMixTotal > 100) {
					// Total is over 100
					document.getElementById("payer-error-message").innerHTML = "Location Payer Mix Total must equal 100% to get the correct results. Please remove " + userMixDifference + "% to correct this.";
				} else {
					// Total is under 100
					document.getElementById("payer-error-message").innerHTML = "Location Payer Mix Total must equal 100% to get the correct results. Please add " + Math.abs(userMixDifference) + "% to correct this.";
				}
			} else {
				checkLocationPayerMixTotal();
				document.getElementById("payer-error-message").innerHTML = "";
				document.getElementById("payer-error-message").style.display = "none";
			}
		}
	</script>

	<script>
		// Complete exam has been checked, all other checkboxes should be unchecked and emboli/bubble grayed out.
		function completeExamChecked() {
			if (document.getElementById("tcd-complete-exam").checked === true) {
				document.getElementById("complete-exam-group").style.opacity = "100%";
				document.getElementById("addon-options-group").style.opacity = "100%";

				document.getElementById("tcd-limited-exam").checked = false;

				document.getElementById("emboli-bubble-group").style.opacity = "50%";
				document.getElementById("emboli-exam").checked = false;
				document.getElementById("bubble-exam").checked = false;
			} else {
				document.getElementById("complete-exam-group").style.opacity = "100%";
				document.getElementById("addon-options-group").style.opacity = "50%";
				document.getElementById("tcd-bundle-exams-1").checked = false;
				document.getElementById("tcd-bundle-exams-2").checked = false;
				document.getElementById("tcd-bundle-exams-3").checked = false;

				document.getElementById("tcd-limited-exam").checked = false;

				document.getElementById("emboli-bubble-group").style.opacity = "100%";
				document.getElementById("emboli-exam").checked = false;
				document.getElementById("bubble-exam").checked = false;
			}
		}

		// One of the addon options has been checked, all other checkboxes should be unchecked and emboli/bubble grayed out.
		function addonOptionChecked() {
			document.getElementById("complete-exam-group").style.opacity = "100%";
			document.getElementById("tcd-complete-exam").checked = true;
			document.getElementById("addon-options-group").style.opacity = "100%";

			document.getElementById("tcd-limited-exam").checked = false;

			document.getElementById("emboli-bubble-group").style.opacity = "50%";
			document.getElementById("emboli-exam").checked = false;
			document.getElementById("bubble-exam").checked = false;
		}

		// Limited Exam has been checked.
		function limitedExamChecked() {
			if (document.getElementById("tcd-limited-exam").checked === true) {
				document.getElementById("complete-exam-group").style.opacity = "50%";
				document.getElementById("tcd-complete-exam").checked = false;
				document.getElementById("addon-options-group").style.opacity = "50%";
				document.getElementById("tcd-bundle-exams-1").checked = false;
				document.getElementById("tcd-bundle-exams-2").checked = false;
				document.getElementById("tcd-bundle-exams-3").checked = false;

				document.getElementById("emboli-bubble-group").style.opacity = "100%";
				document.getElementById("emboli-exam").checked = false;
				document.getElementById("bubble-exam").checked = false;
			} else {
				document.getElementById("complete-exam-group").style.opacity = "100%";
				document.getElementById("addon-options-group").style.opacity = "50%";

				document.getElementById("emboli-bubble-group").style.opacity = "100%";
				document.getElementById("emboli-exam").checked = false;
				document.getElementById("bubble-exam").checked = false;
			}
		}

		// Emboli or Bubble exam has been checked
		function emboliBubbleExamChecked() {
			if (document.getElementById("emboli-exam").checked === true || document.getElementById("bubble-exam").checked === true) {
				document.getElementById("complete-exam-group").style.opacity = "50%";
				document.getElementById("tcd-complete-exam").checked = false;
				document.getElementById("addon-options-group").style.opacity = "50%";
				document.getElementById("tcd-bundle-exams-1").checked = false;
				document.getElementById("tcd-bundle-exams-2").checked = false;
				document.getElementById("tcd-bundle-exams-3").checked = false;

				document.getElementById("emboli-bubble-group").style.opacity = "100%";
			} else {
				document.getElementById("complete-exam-group").style.opacity = "100%";
				document.getElementById("addon-options-group").style.opacity = "50%";
			}
		}
	</script>

	<script>
		function clearEmptyField(item) {
			const elementToCheck = document.getElementById(item.id).value;

			if (elementToCheck === "0") {
				document.getElementById(item.id).value = "";
			}
		}

		// When a percentage field loses focus, and its empty, put the zero back.
		function returnZero(item) {
			const elementToCheck = document.getElementById(item.id).value;

			if (elementToCheck === "") {
				document.getElementById(item.id).value = "0";
			}
		}
	</script>

	<script>
		//API Call - Take all the data and process it.
		function apiCall() {
			var request_results;
			var emboliChecked = false;
			var bubbleChecked = false;

			// Emboil exam selection.
			if (document.getElementById("tcd-bundle-exams-2").checked === true || document.getElementById("emboli-exam").checked === true) {
				emboliChecked = true;
			}

			// Bubble exam selection.
			if (document.getElementById("tcd-bundle-exams-3").checked === true || document.getElementById("bubble-exam").checked === true) {
				bubbleChecked = true;
			}

			// Grab data from the form
			let zipcode = document.getElementById("investment-form-zip").value;

			// Exam types
			let complete_exam = document.getElementById("tcd-complete-exam").checked;
			let limited_exam = document.getElementById("tcd-limited-exam").checked;
			let vmr_exam = document.getElementById("tcd-bundle-exams-1").checked;

			let emboli_exam = emboliChecked;
			let bubble_exam = bubbleChecked;


			let bundle_exams = false;
			let facility_type = "Hospital";
			let include_tte = document.getElementById("tte_yes").checked;
			let payer_private = parseInt(document.getElementById("investment-form-private-insurance").value);
			let payer_medicare = parseInt(document.getElementById("investment-form-medicare").value);
			let payer_medicaid = parseInt(document.getElementById("investment-form-medicade").value);
			let payer_unpaid = parseInt(document.getElementById("investment-form-uninsured").value);
			let monthly_lease = parseFloat(document.getElementById("investment-input-monthly-lease-payment").value);
			let annual_patients = parseInt(document.getElementById("investment-form-annual-patients").value);
			let private_rate = 140;

			const apiKey = "d7196338da7842d5b5c5588dc39396e2";
			const dataToSend = {
				zipcode: zipcode,
				complete_exam: complete_exam,
				bundle_exams: bundle_exams,
				limited_exam: limited_exam,
				vmr_exam: vmr_exam,
				emboli_exam: emboli_exam,
				bubble_exam: bubble_exam,
				facility_type: facility_type,
				include_tte: include_tte,
				payer_private: payer_private,
				payer_medicare: payer_medicare,
				payer_medicaid: payer_medicaid,
				payer_unpaid: payer_unpaid,
				monthly_lease: monthly_lease,
				annual_patients: annual_patients,
				private_rate: private_rate
			};

			//console.log(dataToSend);

			fetch('https://xfefqhtcvk.us-west-2.awsapprunner.com/calc', {
					method: 'POST',
					headers: {
						'accept': 'application / json',
						'Content-Type': 'application/json',
						'X-API-Key': apiKey
					},
					body: JSON.stringify(dataToSend)
				})
				.then(response => response.json())
				.then(data =>
					request_results = data
				)

				//.then(data => console.log(request_results))

				//.then(data => document.getElementById("investment-form-region").value = request_results.medicare_locality)

				.then(data => document.getElementById("investment-output-average-scan-revenue").value = "$" + Number.parseFloat(request_results.average_scan_revenue)
					.toLocaleString('en-US', {
						minimumFractionDigits: 2,
						maximumFractionDigits: 2
					}))

				.then(data => document.getElementById("investment-output-monthly-revenue").value = "$" + Number.parseFloat(request_results.monthly_revenue)
					.toLocaleString('en-US', {
						minimumFractionDigits: 2,
						maximumFractionDigits: 2
					}))

				.then(data => document.getElementById("investment-output-break-even").value = request_results.monthly_scans_to_break_even)

				.then(data => document.getElementById("investment-output-monthly-profit").value = "$" + Number.parseFloat(request_results.monthly_profit)
					.toLocaleString('en-US', {
						minimumFractionDigits: 2,
						maximumFractionDigits: 2
					}))

				.catch(error => console.error('Error submitting data:', error));

			document.getElementById("investment-output-form").style.display = "block";
			document.getElementById("results").scrollIntoView({
				behavior: "smooth"
			});
			document.getElementById("estimated-financials").focus({
				focusVisible: false
			});
		}

		//API Call - Zip Code processing only.
		function apiCallZipOnly() {
			var request_results;

			const zipfieldLength = document.getElementById("investment-form-zip").value;

			if (zipfieldLength.length === 5) {
				let zipcode = document.getElementById("investment-form-zip").value;
				const complete_exam = false;
				const bundle_exams = false;
				const limited_exam = false;
				const vmr_exam = false;
				const emboli_exam = false;
				const bubble_exam = false;
				const facility_type = "Hospital";
				const include_tte = false;
				const payer_private = 25;
				const payer_medicare = 25;
				const payer_medicaid = 25;
				const payer_unpaid = 25;
				const monthly_lease = 100;
				const annual_patients = 100;
				const private_rate = 0;

				const apiKey = "d7196338da7842d5b5c5588dc39396e2";
				const dataToSend = {
					zipcode: zipcode,
					complete_exam: complete_exam,
					bundle_exams: bundle_exams,
					limited_exam: limited_exam,
					vmr_exam: vmr_exam,
					emboli_exam: emboli_exam,
					bubble_exam: bubble_exam,
					facility_type: facility_type,
					include_tte: include_tte,
					payer_private: payer_private,
					payer_medicare: payer_medicare,
					payer_medicaid: payer_medicaid,
					payer_unpaid: payer_unpaid,
					monthly_lease: monthly_lease,
					annual_patients: annual_patients,
					private_rate: private_rate
				};

				fetch('https://xfefqhtcvk.us-west-2.awsapprunner.com/calc', {
						method: 'POST',
						headers: {
							'accept': 'application / json',
							'Content-Type': 'application/json',
							'X-API-Key': apiKey
						},
						body: JSON.stringify(dataToSend)
					})
					.then(response => response.json())
					.then(data => request_results = data)

					//.then(data => console.log(request_results))

					.then(data => document.getElementById("investment-form-region").value = request_results.medicare_mac.toString().padStart(5, "0") + request_results.medicare_locality.toString().padStart(2, "0"))

					.catch(error => console.error('Error submitting data:', error));
			} else {
				document.getElementById("investment-form-region").value = "";
			}
		}
	</script>

	<script>
		// Variables to monitor all the required fields.
		let formCheck_zipValid = false;
		let formCheck_annualPatientsValid = false;
		let formCheck_locationPayerMixValid = false;
		let formCheck_leaseValid = false;
		let formCheck_examTypes = false;

		// Check the validity of the zip field. If field is less than 5 digits, mark it as bad.
		// This check doesn't really know if you have entered a real ZIP code, just that 5 digits exist.
		function checkIfZipValid() {
			const fieldToCheck = document.getElementById("investment-form-zip");
			const fieldToCheckValue = fieldToCheck.value;

			if (fieldToCheckValue.length < 5) {
				fieldToCheck.style.border = "2px solid red";
				formCheck_zipValid = false;
			} else {
				fieldToCheck.style.border = "2px solid transparent";
				formCheck_zipValid = true;

				document.getElementById("zip-label").innerHTML = "Local Zip Code";
			}
			submitButtonColorCheck();
		}

		// Check to ensure Annual Patients is not blank or 0.
		function checkAnnualPatients() {
			const fieldToCheck = document.getElementById("investment-form-annual-patients");
			const fieldToCheckValue = fieldToCheck.value;

			if (fieldToCheckValue === "0" || fieldToCheckValue === "") {
				fieldToCheck.style.border = "2px solid red";
				formCheck_annualPatientsValid = false;
			} else {
				fieldToCheck.style.border = "2px solid transparent";
				formCheck_annualPatientsValid = true;

				document.getElementById("patients-label").innerHTML = "Annual Patients";
			}
			submitButtonColorCheck();
		}

		// Check Location Payer Mix total to ensure it is 100%
		function checkLocationPayerMixTotal() {
			const fieldToCheck = document.getElementById("investment-form-payer-total");
			const fieldToCheckValue = fieldToCheck.value;

			if (fieldToCheckValue != "100") {
				fieldToCheck.style.border = "2px solid red";
				formCheck_locationPayerMixValid = false;
			} else {
				fieldToCheck.style.border = "2px solid transparent";
				formCheck_locationPayerMixValid = true;
			}
			submitButtonColorCheck();
		}

		// Check the monthly lease payment to ensure its not blank
		function checkLeasePayment() {
			const fieldToCheck = document.getElementById("investment-input-monthly-lease-payment");
			const fieldToCheckValue = fieldToCheck.value;

			if (fieldToCheckValue === "0" || fieldToCheckValue === "") {
				fieldToCheck.style.border = "2px solid red";
				formCheck_leaseValid = false;
			} else {
				fieldToCheck.style.border = "2px solid transparent";
				formCheck_leaseValid = true;

				document.getElementById("lease-label").innerHTML = "Monthly Lease Payment";
			}
			submitButtonColorCheck();
		}

		// Check to see if at least one exam type is marked.
		function checkExamType() {
			const fieldToCheck1 = document.getElementById("tcd-complete-exam");
			const fieldToCheck2 = document.getElementById("tcd-limited-exam");
			const fieldToCheck3 = document.getElementById("emboli-exam");
			const fieldToCheck4 = document.getElementById("bubble-exam");

			// At least one checkbox will need to be checked.
			if (fieldToCheck1.checked === false && fieldToCheck2.checked === false && fieldToCheck3.checked === false && fieldToCheck4.checked === false) {
				// Problem detected
				fieldToCheck1.style.outline = "2px solid red";
				fieldToCheck2.style.outline = "2px solid red";
				fieldToCheck3.style.outline = "2px solid red";
				fieldToCheck4.style.outline = "2px solid red";

				formCheck_examTypes = false;

				document.getElementById("exam-error-message").innerHTML = "Error: At least one exam type must be selected.";
				document.getElementById("exam-error-message").style.display = "block";
			} else {
				// Everything looks fine 
				fieldToCheck1.style.outline = "2px solid transparent";
				fieldToCheck2.style.outline = "2px solid transparent";
				fieldToCheck3.style.outline = "2px solid transparent";
				fieldToCheck4.style.outline = "2px solid transparent";

				formCheck_examTypes = true;
				document.getElementById("exam-error-message").innerHTML = "";
				document.getElementById("exam-error-message").style.display = "none";
			}
		}

		function submitButtonColorCheck() {
			if (formCheck_zipValid === true && formCheck_annualPatientsValid === true && formCheck_locationPayerMixValid === true && formCheck_leaseValid === true) {
				// Evything looks fine
				document.getElementById("submitButton").style.backgroundColor = "#54BBE4";
				document.getElementById("submitButton").style.color = "black";
			} else {
				// Still some problems
				document.getElementById("submitButton").style.backgroundColor = "#35498F";
				document.getElementById("submitButton").style.color = "white";
			}
		}

		function checkIfAbleToSubmit() {
			if (formCheck_zipValid === true && formCheck_annualPatientsValid === true && formCheck_locationPayerMixValid === true && formCheck_leaseValid === true && formCheck_examTypes === true) {
				document.getElementById("submitButton").style.backgroundColor = "#54BBE4";
				document.getElementById("submitButton").style.color = "black";

				// Go ahead and contact the API
				apiCall();
			} else {
				document.getElementById("submitButton").style.backgroundColor = "#35498F";
				document.getElementById("submitButton").style.color = "white";

				checkExamType();

				if (formCheck_zipValid === false) {
					checkIfZipValid();

					document.getElementById("zip-label").innerHTML = "Local Zip Code - Required";
					document.getElementById("zipcode").scrollIntoView({
						behavior: "smooth"
					});
					document.getElementById("zip-label").focus();
				} else if (formCheck_annualPatientsValid === false) {
					checkAnnualPatients();

					document.getElementById("patients-label").innerHTML = "Annual Patients - Required";
					document.getElementById("annualPatients").scrollIntoView({
						behavior: "smooth"
					});
					document.getElementById("patients-label").focus();
				} else if (formCheck_locationPayerMixValid === false) {
					checkLocationPayerMixTotal();

					document.getElementById("payermix").scrollIntoView({
						behavior: "smooth"
					});
					document.getElementById("investment-form-private-insurance").focus();
				} else if (formCheck_leaseValid === false) {
					checkLeasePayment();

					document.getElementById("lease-label").innerHTML = "Monthly Lease Payment - Required";
					document.getElementById("leasePayment").scrollIntoView({
						behavior: "smooth"
					});
					document.getElementById("lease-label").focus();
				} else if (formCheck_examTypes === false) {
					checkExamType();

					document.getElementById("examTypes").scrollIntoView({
						behavior: "smooth"
					});
					document.getElementById("tcd-complete-exam").focus();
				}
			}
		}
	</script>


	<div class="investment-header">
		<a href="https://neurasignal.com/"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 268.23 53" width="200">
				<defs>
					<style>
						.cls-1 {
							fill: #fff;
						}

						.cls-2 {
							fill: #37a5dd;
						}
					</style>
				</defs>
				<polygon class="cls-1" points="64.85 39.66 64.85 14.36 67.71 14.36 83.15 34.93 83.15 14.36 86.01 14.36 86.01 39.66 83.15 39.66 67.71 19.13 67.71 39.66 64.85 39.66" />
				<path class="cls-1" d="M107.92,33.72c-.44,4.18-4.03,6.38-8.5,6.38-5.13,0-8.87-3.08-8.87-10.01,0-6.3,3.59-10.04,8.87-10.04,5.61,0,8.43,3.41,8.43,8.36v2.2h-14.44c-.04,4.73,2.2,7.15,6.09,7.15,2.9,0,5.5-1.17,5.94-4.4l2.49.37ZM93.48,28.33h11.58v-.66c0-2.93-1.8-5.28-5.61-5.28-3.52,0-5.76,2.27-5.97,5.94" />
				<path class="cls-1" d="M112.03,32.95v-12.46h2.71v12.46c0,2.71,1.83,4.8,5.17,4.8s5.17-2.09,5.17-4.8v-12.46h2.71v12.46c0,4.58-3.08,7.15-7.88,7.15s-7.88-2.57-7.88-7.15" />
				<path class="cls-1" d="M143.11,20.27v2.64h-.51c-4.55,0-6.78,3.34-6.78,7.52v9.24h-2.75v-19.17h2.68v4.33h.11c.99-3.3,3.85-4.55,6.82-4.55h.44Z" />
				<path class="cls-1" d="M152.93,28.15h4.95v-1.43c0-3.04-1.76-4.33-4.77-4.33-2.31,0-4.58.48-5.06,3.59h-.15l-2.27-.59c.59-4.77,4.84-5.35,7.66-5.35,3.89,0,7.29,1.76,7.29,6.78v12.83h-2.46v-3.3h-.15c-1.25,2.38-3.7,3.59-6.67,3.59-3.45,0-6.34-1.9-6.34-5.83,0-4.73,3.92-5.98,7.96-5.98M157.88,30.35h-4.73c-3.12,0-5.35.73-5.35,3.67,0,2.31,1.65,3.56,4.18,3.56,2.68,0,5.9-1.54,5.9-4.99v-2.24Z" />
				<path class="cls-1" d="M181.08,32.36c0-6.6-16.28-1.43-16.28-11.36,0-4.62,3.96-7.08,9.27-7.08s9.49,2.09,9.75,7.4l-2.53.48h-.18c-.37-4-3.37-5.28-7.15-5.28s-6.16,1.5-6.16,4.44c0,6.63,16.28,1.54,16.28,11.11,0,6.09-5.1,8.03-9.79,8.03-5.02,0-9.75-1.91-10.01-7.48l2.57-.55h.18c.29,4.22,3.59,5.43,7.33,5.43,3.23,0,6.71-1.06,6.71-5.13" />
				<path class="cls-1" d="M191.38,17.41h-2.97v-3.04h2.97v3.04ZM191.27,39.66h-2.75v-19.17h2.75v19.17Z" />
				<path class="cls-1" d="M203.77,33.72c-1.36,0-2.68-.26-3.74-.77-.88.59-1.21,1.25-1.21,1.91,0,.92.81,1.76,2.49,1.76h5.72c3.81,0,6.01,1.58,6.01,4.69,0,3.81-3.04,5.86-9.05,5.86-6.45,0-8.61-1.87-8.61-4.95,0-1.69.99-3.37,3.37-3.89v-.07c-1.58-.37-2.57-1.54-2.57-3.01,0-1.14.62-2.46,2.24-3.19-1.43-1.14-2.27-2.93-2.27-5.17,0-4.14,2.86-6.82,7.62-6.82,1.21,0,2.53.18,3.26.51v-.04h6.42v2.35h-3.67c1.06,1.03,1.69,2.38,1.69,4.11,0,4.43-3.19,6.71-7.7,6.71M201.75,39.11c-2.46,0-3.52,1.43-3.52,2.9,0,1.94,1.43,2.82,5.72,2.82,4.58,0,6.23-.95,6.23-3.3,0-1.58-1.21-2.42-3.15-2.42h-5.28ZM203.77,31.41c3.08,0,4.84-1.61,4.84-4.51s-1.76-4.51-4.84-4.51-4.77,1.61-4.77,4.51,1.76,4.51,4.77,4.51" />
				<path class="cls-1" d="M219.6,20.49v3.26h.15c1.17-2.64,4-3.7,6.67-3.7,4.07,0,6.74,2.38,6.74,6.85v12.76h-2.71v-12.57c0-2.79-1.36-4.69-4.66-4.69-4.25,0-5.98,3.26-5.98,6.27v11h-2.75v-19.17h2.53Z" />
				<path class="cls-1" d="M245.08,28.15h4.95v-1.43c0-3.04-1.76-4.33-4.77-4.33-2.31,0-4.58.48-5.06,3.59h-.15l-2.27-.59c.59-4.77,4.84-5.35,7.66-5.35,3.89,0,7.29,1.76,7.29,6.78v12.83h-2.46v-3.3h-.15c-1.25,2.38-3.7,3.59-6.67,3.59-3.45,0-6.34-1.9-6.34-5.83,0-4.73,3.92-5.98,7.96-5.98M250.03,30.35h-4.73c-3.11,0-5.35.73-5.35,3.67,0,2.31,1.65,3.56,4.18,3.56,2.68,0,5.9-1.54,5.9-4.99v-2.24Z" />
				<rect class="cls-1" x="258.16" y="14.36" width="2.75" height="25.29" />
				<path class="cls-1" d="M262.99,17.34v-2.41h-1.03v-.43h2.52v.43h-1.01v2.41h-.48ZM266.86,17.34h-.52l-.9-2.23v2.23h-.48v-2.84h.7l.94,2.35.94-2.35h.69v2.84h-.46v-2.23l-.91,2.23Z" />
				<path class="cls-2" d="M26.5,0C11.86,0,0,11.86,0,26.5s11.86,26.5,26.5,26.5,26.5-11.86,26.5-26.5S41.13,0,26.5,0M15.57,35.83c-5.1,0-9.24-4.14-9.24-9.24s4.14-9.24,9.24-9.24,9.24,4.14,9.24,9.24-4.14,9.24-9.24,9.24M32.84,32.35c-3.18,0-5.76-2.58-5.76-5.76s2.58-5.76,5.76-5.76,5.76,2.58,5.76,5.76-2.58,5.76-5.76,5.76M43.73,29.71c-1.8,0-3.26-1.46-3.26-3.25s1.46-3.26,3.26-3.26,3.25,1.46,3.25,3.26-1.46,3.25-3.25,3.25" />
			</svg></a>
	</div>

	<div class="form-background">
		<div class="investment-page-margin">
			<div class="investment-input-form">
				<form action="" method="get">

					<!-- Start: Hospital Info -->
					<h1 class="investment-text-header">
						Hospital/Clinic Information
					</h1>

					<div class="investment-section-border">
						<div class="investment-container-2item">
							<div class="investment-item-2row-item1 mobile-padding">
								<div id="zipcode" class="investment-text-15px-label">
									<label id="zip-label" class="investment-label-padding" for="investment-form-zip">Local Zip Code</label>
									<input class="investment-input-field" type="tel" name="investment-form-zip" id="investment-form-zip" maxlength="5" inputmode="numeric" pattern="[0-9]{5}" required aria-required="true" aria-label="5 digit zip code" title="5 digit zip code" oninput="apiCallZipOnly();" onblur="checkIfZipValid();" />
								</div>
							</div>

							<div class="investment-item-2row-item2">
								<div class="investment-text-15px-label">
									<label class="investment-label-padding" for="investment-form-region">Specific MAC Locality</label>
									<input class="investment-input-field" type="tel" name="investment-form-region" id="investment-form-region" readonly />
								</div>
							</div>
						</div>

						<hr class="investment-seperator">

						<div class="investment-container-2item">
							<div class="investment-item-2row-item1 mobile-padding">
								<div id="annualPatients" class="investment-text-15px-label">
									<label id="patients-label" class="investment-label-padding" for="investment-form-annual-patients">Annual Patients</label>
									<input class="investment-input-field" type="tel" name="investment-form-annual-patients" id="investment-form-annual-patients" inputmode="numeric" pattern="[0-9]*" required aria-required="true" aria-label="Number of annual patients" title="Number of annual patients" oninput="averagePatientsCalc();" onblur="checkAnnualPatients();" />
								</div>
							</div>

							<div class="investment-item-2row-item2">
								<div class="investment-text-15px-label">
									<label class="investment-label-padding" for="investment-form-average-monthly-patients">Average Monthly Patients</label>
									<input class="investment-input-field" type="tel" name="investment-form-average-monthly-patients" id="investment-form-average-monthly-patients" readonly />
								</div>
							</div>
						</div>

						<hr class="investment-seperator">

						<div class="investment-text-15px-label">
							Location Payer Mix
						</div>

						<div class="investment-container-2item">
							<div class="investment-item-2row-item1">
								<div id="payermix" class="investment-text-14px-label investment-element-padding">
									<label class="investment-label-padding" for="investment-form-private-insurance">Private Insurance*</label>
									<div class="form-group-full-percentage">
										<input class="investment-input-field" type="tel" name="investment-form-private-insurance" id="investment-form-private-insurance" inputmode="numeric" pattern="[0-9]*" maxlength="3" required oninput="locationPayerMix();" onclick="clearEmptyField(this);" onblur="returnZero(this);" value="0" />
										<label>%</label>
									</div>
								</div>
							</div>

							<div class="investment-item-2row-item2">
								<div class="investment-text-14px-label investment-element-padding">
									<label class="investment-label-padding" for="investment-form-medicade">Medicaid</label>
									<div class="form-group-full-percentage">
										<input class="investment-input-field" type="tel" name="investment-form-medicade" id="investment-form-medicade" inputmode="numeric" pattern="[0-9]*" maxlength="3" required oninput="locationPayerMix();" onclick="clearEmptyField(this);" onblur="returnZero(this);" value="0" />
										<label>%</label>
									</div>
								</div>
							</div>
						</div>

						<div class="investment-container-2item">
							<div class="investment-item-2row-item1">
								<div class="investment-text-14px-label investment-element-padding">
									<label class="investment-label-padding" for="investment-form-medicare">Medicare</label>
									<div class="form-group-full-percentage">
										<input class="investment-input-field" type="tel" name="investment-form-medicare" id="investment-form-medicare" inputmode="numeric" pattern="[0-9]*" maxlength="3" required oninput="locationPayerMix();" onclick="clearEmptyField(this);" onblur="returnZero(this);" value="0" />
										<label>%</label>
									</div>
								</div>
							</div>

							<div class="investment-item-2row-item2">
								<div class="investment-text-14px-label investment-element-padding">
									<label class="investment-label-padding" for="investment-form-uninsured">Uninsured / No-Pay</label>
									<div class="form-group-full-percentage">
										<input class="investment-input-field" type="tel" name="investment-form-uninsured" id="investment-form-uninsured" inputmode="numeric" pattern="[0-9]*" maxlength="3" required oninput="locationPayerMix();" onclick="clearEmptyField(this);" onblur="returnZero(this);" value="0" />
										<label>%</label>
									</div>
								</div>
							</div>
						</div>
						<div class="investment-text-15px-label investment-element-padding">

							<label class="investment-label-padding" for="investment-form-payer-total">Total</label>
							<div class="form-group-full-percentage">
								<input class="investment-input-field" type="tel" name="investment-form-payer-total" id="investment-form-payer-total" readonly />
								<label>%</label>
							</div>

						</div>
						<div>
							<p class="investment-text-14px-label" id="payer-error-message" style="display: none;"></p>
						</div>
					</div>
					<!-- End: Hospital Info -->

					<!-- Start: Additional Information -->
					<div>
						<h2 class="investment-text-header">
							Additional Information
						</h2>

						<div class="investment-section-border">

							<div class="investment-text-15px-label">
								<fieldset class="fieldset-clear">
									<span>Is TTE or Other Imaging Procedure Performed on the Same Day?</span>
									<input type="radio" id="tte_yes" name="tte_performed_same" value="true">
									<label for="tte_yes">Yes</label>
									<input type="radio" id="tte_no" name="tte_performed_same" value="false" checked>
									<label for="tte_no">No</label>
								</fieldset>
							</div>

							<div id="leasePayment" class="investment-text-15px-label investment-element-padding">
								<label id="lease-label" class="investment-label-padding" for="investment-input-monthly-lease-payment">Monthly Lease Payment</label>
								<div class="form-group-full-dollars">
									<label>$</label>
									<input class="investment-input-field" type="tel" name="investment-input-monthly-lease-payment" id="investment-input-monthly-lease-payment" inputmode="numeric" pattern="[0-9]+\.[0-9]{2}" required aria-required="true" aria-label="Monthly lease payment" onblur="checkLeasePayment();" />
								</div>
							</div>
						</div>

					</div>
					<!-- End: Additional Information -->

					<!-- Start: Exam Types -->
					<div>
						<h2 class="investment-text-header-2line">
							Exam Types
						</h2>

						<div class="investment-text-subheader">
							Select All That Apply<br>(At Least One Exam Must Be Selected)
						</div>

						<div id="examTypes" class="investment-section-border">
							<fieldset class="fieldset-clear">
								<div id="complete-exam-group" class="complete-exam-group">
									<div class="investment-text-15px-label">
										<input class="input-checkbox-override" type="checkbox" name="tcd-complete-exam" id="tcd-complete-exam" value="" onclick="completeExamChecked(); checkExamType();" /> <label for="tcd-complete-exam">TCD Complete Study - 93886</label>
									</div>
								</div>

								<div id="addon-options-group" class="addon-options-group">
									<div class="investment-list-indent investment-text-14px-label investment-element-padding">
										<input type="checkbox" name="tcd-bundle-exams-1" id="tcd-bundle-exams-1" value="" onclick="addonOptionChecked();" /> <label for="tcd-bundle-exams-1">TCD Vasoreactivity Study - 93896</label>
									</div>

									<div class="investment-list-indent investment-text-14px-label investment-element-padding">
										<input type="checkbox" name="tcd-bundle-exams-2" id="tcd-bundle-exams-2" value="" onclick="addonOptionChecked();" /> <label for="tcd-bundle-exams-2">TCD Emboli Monitoring Study - 93897</label>
									</div>

									<div class="investment-list-indent investment-text-14px-label investment-element-padding">
										<input type="checkbox" name="tcd-bundle-exams-3" id="tcd-bundle-exams-3" value="" onclick="addonOptionChecked();" /> <label for="tcd-bundle-exams-3">TCD Bubble Study - 93898</label>
									</div>
								</div>

								<div class="investment-text-15px-label investment-element-padding">
									<input type="checkbox" name="tcd-limited-exam" id="tcd-limited-exam" value="" onclick="limitedExamChecked(); checkExamType();" /> <label for="tcd-limited-exam">TCD Limited Study - 93888</label>
								</div>

								<div id="emboli-bubble-group" class="emboli-bubble-group">
									<div class="investment-text-15px-label investment-element-padding">
										<input type="checkbox" name="emboli-exam" id="emboli-exam" value="" onclick="emboliBubbleExamChecked(); checkExamType();" /> <label for="emboli-exam">TCD Emboli Monitoring Study - 93892</label>
									</div>

									<div class="investment-text-15px-label investment-element-padding">
										<input type="checkbox" name="bubble-exam" id="bubble-exam" value="" onclick="emboliBubbleExamChecked(); checkExamType();" /> <label for="bubble-exam">TCD Bubble Study - 93893</label>
									</div>
								</div>
							</fieldset>

							<div>
								<p class="investment-text-14px-label" id="exam-error-message" style="display: none;"></p>
							</div>
						</div>

						<p>&nbsp;</p>

						<div style="text-align: center;">
							<input id="submitButton" class="submitButton" onclick="checkIfAbleToSubmit();" type="button" value="Calculate" />
							<!-- <input class="submitButton" onclick="apiCall();" type="submit" value="Calculate" /> -->
						</div>

					</div>
					<!-- End: Exam Types -->

				</form>

				<p>&nbsp;</p>

				<!-- Start: Estimate Financials -->
				<div id="investment-output-form" class="investment-output-form">
					<div id="estimated-financials" class="investment-text-header">
						Estimated Financials
					</div>

					<div class="investment-section-border">
						<div class="investment-container-3item">
							<div class="investment-item-3row-item1">
								<label class="investment-label-padding investment-text-14px-label" for="investment-output-average-scan-revenue">Average Scan Revenue</label>
								<input class="investment-input-field" type="text" name="investment-output-average-scan-revenue" id="investment-output-average-scan-revenue" readonly />
							</div>

							<div class="investment-item-3row-item2">
								<label class="investment-label-padding investment-text-14px-label" for="investment-output-monthly-revenue">Monthly Revenue</label>
								<input class="investment-input-field" type="text" name="investment-output-monthly-revenue" id="investment-output-monthly-revenue" readonly />
							</div>

							<div class="investment-item-3row-item3">
								<label class="investment-label-padding investment-text-14px-label" for="investment-output-break-even">Scans Required to Break Even</label>
								<input class="investment-input-field" type="text" name="investment-output-break-even" id="investment-output-break-even" readonly />
							</div>
						</div>

						<div class="investment-element-padding">
							<label class="investment-label-padding investment-text-14px-label" for="investment-output-monthly-profit">Monthly Profit</label>
							<input class="investment-input-field-fullwidth" type="text" name="investment-output-monthly-profit" id="investment-output-monthly-profit" readonly />
						</div>
					</div>
				</div>

				<p>&nbsp;</p>

				<p class="investment-text-disclaimer">*private pay ratio set at 1.4x of Medicare rate</p>

				<div id="results" style="margin-bottom: 50px;"></div>

			</div>
			<!-- End: Estimate Financials -->
		</div>
	</div>

	<script>
		// Local Zip Code
		document.getElementById('investment-form-zip').addEventListener('keypress', function(event) {
			if (!/[0-9]/.test(event.key)) {
				event.preventDefault();
			}
		});

		// Annual Patients
		document.getElementById('investment-form-annual-patients').addEventListener('keypress', function(event) {
			if (!/[0-9]/.test(event.key)) {
				event.preventDefault();
			}
		});

		// Private Insurance %
		document.getElementById('investment-form-private-insurance').addEventListener('keypress', function(event) {
			if (!/[0-9]/.test(event.key)) {
				event.preventDefault();
			}
		});

		// Medicaid %
		document.getElementById('investment-form-medicade').addEventListener('keypress', function(event) {
			if (!/[0-9]/.test(event.key)) {
				event.preventDefault();
			}
		});

		// Medicare %
		document.getElementById('investment-form-medicare').addEventListener('keypress', function(event) {
			if (!/[0-9]/.test(event.key)) {
				event.preventDefault();
			}
		});

		// Uninsured / No-Pay %
		document.getElementById('investment-form-uninsured').addEventListener('keypress', function(event) {
			if (!/[0-9]/.test(event.key)) {
				event.preventDefault();
			}
		});

		//Monthly Lease Payment (allow cents)
		document.getElementById('investment-input-monthly-lease-payment').addEventListener('input', function(e) {
			let value = this.value;

			// Remove any character that isn't a digit or a period
			value = value.replace(/[^0-9.]/g, '');

			// Handle multiple decimal points
			// This splits the string at the first dot and joins the rest without periods
			const parts = value.split('.');
			if (parts.length > 2) {
				value = parts[0] + '.' + parts.slice(1).join('');
			}

			// Limit to 2 decimal places if a decimal exists
			if (parts.length > 1) {
				value = parts[0] + '.' + parts[1].substring(0, 2);
			}

			this.value = value;

			checkLeasePayment();
		});
	</script>

</body>

</html>

<?php
